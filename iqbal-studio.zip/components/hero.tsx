"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section
      aria-labelledby="hero-heading"
      className="relative isolate flex min-h-[100svh] flex-col overflow-hidden bg-neutral-950 text-white"
    >
      {/* Background with subtle zoom effect */}
      <motion.div 
        initial={{ scale: 1.1, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.2, ease: "easeOut" }}
        className="absolute inset-0 z-0"
      >
        <Image
          src="/images/hero-studio.png"
          alt="Studio kreatif"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center"
        />
        <div className="absolute inset-0 bg-black/35" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/45 via-black/20 to-black/65" />
      </motion.div>

      {/* Centered hero content */}
      <div className="relative z-10 mx-auto flex w-full max-w-[1440px] flex-1 flex-col items-center justify-center px-5 pb-24 pt-28 text-center sm:px-8 sm:pb-28 sm:pt-32 lg:px-12">
        
        {/* Badge */}
        <motion.p 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-6 text-[10px] font-semibold uppercase tracking-[0.28em] text-[#c9ff57] sm:mb-8 sm:text-xs"
        >
          Independent Digital Studio
        </motion.p>

        {/* Heading */}
        <motion.h1
          id="hero-heading"
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="max-w-[1100px] text-[clamp(3rem,8.5vw,8rem)] font-semibold uppercase leading-[0.88] tracking-[-0.085em]"
        >
          <span className="block">Bisnis yang</span>
          <span className="block text-white/55">hebat, layak</span>
          <span className="block">tampil hebat.</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-7 max-w-[490px] text-sm leading-6 text-white/80 sm:mt-9 sm:text-base sm:leading-7"
        >
          Website yang dirancang untuk memperkuat identitas bisnis,
          membangun kepercayaan, dan membantu pelanggan mengenal
          layanan lo.
        </motion.p>

        {/* Buttons */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="mt-7 flex flex-wrap items-center justify-center gap-3 sm:mt-9"
        >
          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
            <Link
              href="#contact"
              className="group inline-flex min-h-12 items-center justify-center gap-3 bg-[#c9ff57] px-5 text-sm font-semibold text-neutral-950 transition-colors duration-200 hover:bg-white sm:px-6"
            >
              Diskusikan proyek
              <ArrowUpRight
                size={18}
                aria-hidden="true"
                className="transition-transform duration-200 group-hover:-translate-y-0.5 group-hover:translate-x-0.5"
              />
            </Link>
          </motion.div>

          <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
            <Link
              href="#work"
              className="inline-flex min-h-12 items-center justify-center gap-2 border border-white/50 px-5 text-sm font-medium text-white transition-colors duration-200 hover:border-white hover:bg-white/10"
            >
              Lihat karya
              <ArrowDownRight size={17} aria-hidden="true" />
            </Link>
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom info */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.8 }}
        className="absolute inset-x-0 bottom-0 z-10"
      >
        <div className="mx-auto flex w-full max-w-[1440px] flex-wrap items-center justify-between gap-3 border-t border-white/25 px-5 py-4 sm:px-8 lg:px-12">
          <p className="text-[9px] font-medium uppercase tracking-[0.16em] text-white/70 sm:text-xs">
            Website Design &amp; Development
          </p>

          <a
            href="#work"
            className="text-[9px] font-medium uppercase tracking-[0.16em] text-white/70 transition-colors hover:text-[#c9ff57] sm:text-xs"
          >
            Explore selected work ↓
          </a>
        </div>
      </motion.div>
    </section>
  );
}